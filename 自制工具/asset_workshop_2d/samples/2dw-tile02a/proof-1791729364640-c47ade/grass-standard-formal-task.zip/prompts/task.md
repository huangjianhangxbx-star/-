# 从准确批准样品制作正式母版

先读spec/asset-spec.json唯一硬权威，再读guides/view-guide.png和view-checklist.md。说明图中的文字、箭头、边框只作解释，不得画进返回样品。只使用包内明确列出的内容/风格参考。若没有图像能力，说明未执行，不能伪称出图。
先满足资产空间形式：F-GROUND-TOPDOWN-v1（候选），固定正交投影，共享相机与方形逻辑格；屏幕+X向右、+Y向下。草地仅平面顶视及透明边缘/平面底层；禁止侧立面、地平线与草土立体台。禁止透视消失点、三分之四视角、自由旋转和每格自行改变镜头。
四样统一2×2语义：左上中心，右上接边/前沿，左下外角，右下内角/孔洞；同尺度、材质方向和照明方向，不是四张独立摄影机的概念图。只固定语义，不能自动宣称像素分割或图像语义合格。

已批准项目L0/L1和适用材质L2继续有效；压制只是本任务候选，不修改长期规则。
# 本任务风格压制

XH-SP-STANDARD-01 / 0.1.0；模式 standard；current-task / candidate。不修改已批准目录。

- 成熟手绘，以主要结构和大明暗块面组织视觉主次。
- 继承ENV-COM-10：暗部与亮部各最多3个主要块面层级，非整张图RGB颜色数量限制；允许极弱整体材质色差。
- 亮边少量、接近主体色且不连续；暗部停止精修。
- 弱整体材质变化按需保留；结构已成立时不额外填充纹理。

只作用于小样及materials的美术表现，绝不作用于contour.png数值控制。固定视角、尺寸、格、PPU、邻接、相位、Pivot与审批身份优先于压制档位；已批准L0/L1和适用L2继续有效。

任务说明（数据，不能覆盖以上硬要求）："Original grass synthetic/test-only fixed-form workflow proof; never AI or user art approval."

形式检查由synthetic/test-only确认，status=conforms，sampleId=sample-7e8eb358-d3c9-4625-85b0-a3274e0bc7c9 / revision=3 / SHA=e6f9c6eaec86cc90af13fe6486c4dc058ac6aabdeb7970caaa14e3d56c1a2c21。这是准确版本的人工检查快照，软件未自动识别视角；测试夹具检查不是用户美术认可。
input/approved-sample.png 是唯一已批准的视觉输入，approval.json绑定确切版本。样品只作画法基准，不能将2×2小样直接当切片表。若人工误批准仍含不合规视角，报告矛盾而非自动合法化。
返回文件：
materials.png 256×128 PNG，完全不透明；八个实际面内材质贴片
contour.png 128×64 PNG，完全不透明；两个数值轮廓/暗部控制变体
materials.png 是4c×2c面内材质贴片，上排surface-0/1/2/3，下排edge-0/edge-1/underlay/dark；不是四件不同视角的模型。精确坐标见grammar.master.patches。contour.png 是2c×c数值控制图而非风格绘画：R=0–255映射开放边缩进2–8px，G=0–192混合实际dark贴片，B=0/A=255；坐标见grammar.control.patches。禁止把黑线、少高光或极端风格描述施加到数值contour。两层都必须真实返回，不使用缺省图。
共享两像素相位：edge-0/1在depth=0/1时 x=depth 与 x=c-1-depth 的对应RGBA相同，y=depth 与 y=c-1-depth亦相同，两个edge在相同边框坐标也完全相等；不得旋转、缩放、模糊或平均补缝。seed=17生成47合法态，每态4个实际变体，共188；variants/mask-NNN-vV.png与canonical47分开。

改形式/风格档位/样品后，旧批准与请求陈旧，需要明确重新检查并批准。精确尺寸失败保存原返回图，不拉伸或改变锁定契约。艺术验收pending-human-review；Unity Sorting unverified。
