# 人工/外部 AI 判错检查点

spec/asset-spec.json 是唯一权威；本文件仅为派生镜像。美术结果待人工/外部 AI 看图审阅，未自动验收。

- ENV-FAIL-01@1 [approved] "微纹理、小高光和精细暗部盖过大形与结构。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-FAIL-02@1 [approved] "概括退化为均匀、机械、空洞的塑料几何平涂。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-FAIL-03@1 [approved] "普通转折被整圈白亮边、过粗描边或密小锯齿抢走注意力。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-FAIL-04@1 [approved] "近黑区域继续精描，或不相关物件出现同类机械斜面切分。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-FAIL-05@1 [approved] "破损平均铺开、过碎；明确重复/联通任务中，显眼独特标记反复出现。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-FAIL-06@1 [approved] "非石材被石材的裂纹、粗黑缝或统一石色污染。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。

可检测的预算/文字冲突（未检测到不等于没有视觉冲突）：
[]
