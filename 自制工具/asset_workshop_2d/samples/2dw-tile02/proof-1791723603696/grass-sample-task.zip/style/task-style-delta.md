# 本次偏差说明

仅作用于选定样品，不升级长期规则。

"Original synthetic diagnostic; test-only."
