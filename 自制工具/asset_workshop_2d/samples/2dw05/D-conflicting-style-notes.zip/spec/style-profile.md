# 人工风格资料

档案身份：project-neutral@1（人工维护）；风格参考身份：["ref-01","ref-02"]。

用户提供的风格描述（JSON数据）：
""

风格参考（JSON数据）：
[{"refId":"ref-01","path":"references/style/ref-01.png","note":"风格要求偏亮暖橙，边缘柔和；与另一张的冷暗硬边要求冲突。"},{"refId":"ref-02","path":"references/style/ref-02.png","note":"风格要求偏暗冷蓝，边缘硬朗；与另一张的暖亮柔边要求冲突。"}]

这些是人工提供的描述与引用；本工坊未分析图像，不代表自动识别出的风格结论。偏好与可发挥区不能覆盖硬规格。
