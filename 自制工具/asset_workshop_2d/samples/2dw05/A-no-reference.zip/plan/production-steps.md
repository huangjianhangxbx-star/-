# 兼容入口：制作步骤

请按 workflow/recipe.json 激活的步骤执行；详细顺序见 workflow/analysis-plan.md、workflow/decision-policy.md 与 workflow/production-plan.md。
先核对输入，再做必要的内容/风格参考观察、需求综合和争议闸门，之后才可制作、验证与交接。
本文件是待执行计划，不是已完成报告。输出硬规格只来自 spec/asset-spec.json。
