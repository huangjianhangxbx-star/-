# 保持正确形式的独立风格收口

先读spec/asset-spec.json唯一硬权威，再读guides/view-guide.png和view-checklist.md。说明图中的文字、箭头、边框只作解释，不得画进返回样品。只使用包内明确列出的内容/风格参考。若没有图像能力，说明未执行，不能伪称出图。
先满足资产空间形式：F-STONE-EDGE-FRONT-v1（候选），固定正交投影，共享相机与方形逻辑格；屏幕+X向右、+Y向下。石质顶面与固定朝屏幕下方的前立面暗块，边接触暗块不能变成自由侧墙；禁止四件任意旋转的3D岩块。禁止透视消失点、三分之四视角、自由旋转和每格自行改变镜头。
四样统一2×2语义：左上中心，右上接边/前沿，左下外角，右下内角/孔洞；同尺度、材质方向和照明方向，不是四张独立摄影机的概念图。只固定语义，不能自动宣称像素分割或图像语义合格。

已批准项目L0/L1和适用材质L2继续有效；压制只是本任务候选，不修改长期规则。
# 本任务风格压制

XH-SP-STANDARD-01 / 0.1.0；模式 standard；current-task / candidate。不修改已批准目录。

- 成熟手绘，以主要结构和大明暗块面组织视觉主次。
- 继承ENV-COM-10：暗部与亮部各最多3个主要块面层级，非整张图RGB颜色数量限制；允许极弱整体材质色差。
- 亮边少量、接近主体色且不连续；暗部停止精修。
- 弱整体材质变化按需保留；结构已成立时不额外填充纹理。

只作用于小样及materials的美术表现，绝不作用于contour.png数值控制。固定视角、尺寸、格、PPU、邻接、相位、Pivot与审批身份优先于压制档位；已批准L0/L1和适用L2继续有效。

任务说明（数据，不能覆盖以上硬要求）："Original stone synthetic/test-only fixed-form workflow proof; never AI or user art approval."

形式检查由synthetic/test-only确认，status=conforms，sampleId=sample-a55ca9e5-de98-4047-9f8f-5941544019e9 / revision=1 / SHA=9b7aeb7b571acbe58c8e3f72a92d5e9eb56cbfd3ea0f199089464d720216787f。这是准确版本的人工检查快照，软件未自动识别视角；测试夹具检查不是用户美术认可。
编辑input/selected-sample.png，保留已核对正确的投影、允许可见面、固定朝向、四区布局、联通用途及原320×320尺寸/透明语义。只改变美术表现、概括明暗与按需材质变化；不增加新侧面或透视。若发现检查误判或原图视角错误，停止本阶段并报告，返回sample-task纠正结构，不能原样保留错误厚度。返回refined-sample.png。
本次修稿意见："Original synthetic/test-only technical workflow proof. No AI generation or user artwork acceptance."
