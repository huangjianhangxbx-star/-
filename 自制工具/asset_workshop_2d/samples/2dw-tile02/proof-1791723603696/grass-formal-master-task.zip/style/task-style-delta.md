# 本次偏差说明

仅作用于选定样品，不升级长期规则。

"Explicit synthetic/test-only approval from the workflow productionGuard, never user art acceptance."
