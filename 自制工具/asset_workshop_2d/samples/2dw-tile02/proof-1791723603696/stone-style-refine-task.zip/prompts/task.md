# 独立风格收口

先读 spec/asset-spec.json（唯一硬规格），再读 style/。若无图像能力，审阅并说明未执行，不伪称已经出图。禁止图内文字/导引/水印，不改变主体与联通要求。参考图片只有本包明确列入的角色才可使用。成熟手绘的大明暗块面，弱整体材质色差；不为填空增加纹理，不做模糊、儿童化、塑料或矢量图标。程序合格不等于人工美术验收。

编辑 input/selected-sample.png，SHA 3c8570e36fa666978cd38e3362cea3fed903d0194d8b8d58202f7f3cee237a42，revision 1。保留主体、布局、边界形态、厚度方向与尺寸 384×384 以及透明语义。只合并细碎裂缝/高光/阴影，整理大块面，不改成其他对象。内容一致性需人工确认。返回 refined-sample.png；原版本仍保留。

锁定项：主体与布局；边界形态；厚度方向；尺寸与透明语义
允许修改：主要明暗块面；高光/裂缝简化；弱整体材质色差
本次偏差："Only an original synthetic style-step input simulation; no AI image generation."
