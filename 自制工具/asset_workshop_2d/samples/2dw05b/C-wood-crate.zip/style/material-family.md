# 材质 wood：正式与实验候选分开

spec/asset-spec.json 是唯一权威；本文件仅为派生镜像。美术结果待人工/外部 AI 看图审阅，未自动验收。

- ENV-WOOD-01@1 [candidate] "实验建议：先表达板块、切面与接合结构，木纹少量概括，不以细密木纹取代结构。"
  来源："2DW-05B M0：AI 木材试验建议，尚无用户认可木材成图；docs/ENVIRONMENT-STYLE.md"；适用：材质 wood。
- ENV-WOOD-02@1 [candidate] "实验建议：不照抄石材裂缝、黑缝与冷灰色板；磨损和亮部依木材任务，不默认亮漆精修。"
  来源："2DW-05B M0：AI 木材试验建议，尚无用户认可木材成图；docs/ENVIRONMENT-STYLE.md"；适用：材质 wood。

候选不作为强制规则；待补材质不虚构画法。正向参考元信息（只有明确选入 references 才携带图片）：
[]
