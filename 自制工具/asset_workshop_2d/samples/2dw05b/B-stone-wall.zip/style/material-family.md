# 材质 stone：正式与实验候选分开

spec/asset-spec.json 是唯一权威；本文件仅为派生镜像。美术结果待人工/外部 AI 看图审阅，未自动验收。

- ENV-STONE-01@1 [approved] "用块体厚实、结构转折和接触关系表达石材；表面弱色差按需，不靠密集小棱面堆砌。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：材质 stone。
- ENV-STONE-02@1 [approved] "避免每块同样圆润、同宽粗黑缝及全边白亮线；缝宽、色调、破损随用途决定。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：材质 stone。
- ENV-STONE-03@1 [approved] "V1 代表成熟手绘环境质感方向，不规定统一灰褐/灰绿色，也不强制复用大裂缝或地砖构图。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：材质 stone。

候选不作为强制规则；待补材质不虚构画法。正向参考元信息（只有明确选入 references 才携带图片）：
[
  {
    "domain": "environment",
    "file": "resources/style-references/approved-stone-v1.png",
    "id": "V1",
    "origin": "用户于 2026-10-10 明确指定最后认可石砖图 V1 为持久正向参考；会话 6ac6fd96-ecd0-83ea-85f5-d628ccf3a6ef",
    "scope": "成熟手绘环境美术质感方向；其他材质不继承其颜色、裂缝或构图。仅实际选为参考时图片进入任务 ZIP。",
    "sha256": "41c21aa13228c01f15034d213e2e948d2f032fa4ebd0d8f6c87c17185332b559"
  }
]
