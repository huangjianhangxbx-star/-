# 已批准场景美术总纲 L0

spec/asset-spec.json 是唯一权威；本文件仅为派生镜像。美术结果待人工/外部 AI 看图审阅，未自动验收。

- ENV-CHAR-01@1 [approved] "成熟二次元手绘环境美术；以概括形状、克制块面表达结构，可借鉴赛璐璐组织但不强制所有物件纯两色。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-CHAR-02@1 [approved] "先读整体与结构，再读材质；安静的大面与必要细节保持主次。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-CHAR-03@1 [approved] "避免写实抛光和密集精修，也避免塑料般空洞的廉价几何平涂。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-CHAR-04@1 [approved] "共享表现原则，具体画法随材质与用途变化；不把石砖颜色、裂缝及构图统一施加给全部素材。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
