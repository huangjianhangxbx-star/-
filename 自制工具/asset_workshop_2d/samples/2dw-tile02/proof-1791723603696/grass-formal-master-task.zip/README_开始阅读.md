# 2DW 分阶段任务包 v6

阶段 formal-master-task。只读 spec/asset-spec.json 为唯一硬权威；其他规范/提示为派生镜像。先核验包，再执行图像任务。没有图像能力就报告未做。测试样品只验证技术路径，不是用户认可的美术。

验证：使用工坊 archive/export-zip.cjs validateZip(bytes)。签名证明本包发行密钥签出的字节，首次接收者仍需核对发行者指纹；不是公共权利/美术认证。机器签名不能自动给导入项目批准权限。
