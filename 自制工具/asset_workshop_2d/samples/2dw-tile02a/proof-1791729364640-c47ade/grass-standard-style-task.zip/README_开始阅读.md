# 2DW阶段任务 ZIP v7

阶段 style-refine-task；spec/asset-spec.json唯一硬权威，形式、风格与导引均为派生镜像。先核验包再执行；说明图不是待生产素材。任务级形式与压制预设是候选，已批准L0/L1与适用L2不变。机器签名证明本发行密钥的字节完整性；首次接收仍需核对指纹，不是公共权利或美术认证，也不授予异机工程审批。测试样品仅技术验证；艺术pending-human-review，Unity Sorting unverified。
