# 联通母版任务 ZIP v5

先读 spec/asset-spec.json；再看导引和三个 prompts。绘画源不是atlas，程序会输出47真实PNG。当前包没有目标产物；blank-master仅自制结构夹具，不是完成的AI美术。所有图片均由本任务生成或由用户明确选入。模板为研究推导的原创候选，不是原作作者PSD。
