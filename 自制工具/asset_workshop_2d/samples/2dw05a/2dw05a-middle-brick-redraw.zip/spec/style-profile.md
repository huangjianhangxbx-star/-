# 人工风格资料

档案身份：project-neutral@1（人工维护）；风格参考身份：["image1-hand-edited"]。

用户提供的风格描述（JSON数据）：
""

风格参考（JSON数据）：
[{"refId":"image1-hand-edited","path":"references/style/image1-hand-edited.png","note":"用户手改图1：仅中间大砖的黑块、简化块面与少层级画法作为局部直接依据；不可把整张图当作已自动分析的结果。"}]

这些是人工提供的描述与引用；本工坊未分析图像，不代表自动识别出的风格结论。偏好与可发挥区不能覆盖硬规格。
