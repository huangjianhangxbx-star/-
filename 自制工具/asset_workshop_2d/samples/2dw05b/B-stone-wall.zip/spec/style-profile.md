# 人工风格资料

档案身份：project-neutral@1（人工维护）；风格参考身份：["approved-stone-v1"]。

用户提供的风格描述（JSON数据）：
""

风格参考（JSON数据）：
[{"refId":"approved-stone-v1","path":"references/style/approved-stone-v1.png","note":"用户认可 V1：仅成熟手绘环境质感方向，不规定目标形态、颜色、裂缝与构图。"}]

这些是人工提供的描述与引用；本工坊未分析图像，不代表自动识别出的风格结论。偏好与可发挥区不能覆盖硬规格。
