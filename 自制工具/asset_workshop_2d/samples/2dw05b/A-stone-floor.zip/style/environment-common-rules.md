# 已批准通用表现 L1

spec/asset-spec.json 是唯一权威；本文件仅为派生镜像。美术结果待人工/外部 AI 看图审阅，未自动验收。

- ENV-COM-01@1 [approved] "大形建立整体，中形补结构，小形点缀；约 6:3:1 仅为视觉启发，不是像素面积或形状数量验收公式。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-02@1 [approved] "普通高亮从主体色体系内稍提亮，必要转折少量提结构，允许整段不画；发光/特殊反射依任务另审。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-03@1 [approved] "不要整圈偏白亮描边、密集短碎亮线、细锯齿与频繁小起伏；断续不等于碎线更多。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-04@1 [approved] "背光、闭塞和接触关系用少量深色块概括；近黑处停止精细刻画，保留结构信息。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域；继承已有 projectStyleContract.positiveRules，仅补充解释，不重复旧契约正文。
- ENV-COM-05@1 [approved] "暗部避免层层精细渐变与复杂内部体积，也不机械切成重复斜向三角形。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-06@1 [approved] "材质变化按需保留，允许极弱、整体化色差；结构已经成立时，不为表现材质额外填充纹理。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-07@1 [approved] "裂纹、磨损与破损从属于形体，疏密有主次；不平均遍布显眼的小裂口。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-08@1 [approved] "明确重复利用/联通时，减少强识别的独特破口与孤立大斑；这不是已实现的无缝拼接算法。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：显式重复利用/联通选择。
- ENV-COM-09@1 [approved] "色彩服从材质、用途及项目主色关系，不统一灰绿色板，也不全面禁止饱和色。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域。
- ENV-COM-10@1 [approved] "暗部与亮部各最多 3 阶指主要明暗块面的层级，不是整张图的颜色数量；允许极弱、整体化材质色差。"
  来源："2DW-05B M0：用户批准及三项修订，2026-10-10；docs/ENVIRONMENT-STYLE.md"；适用：场景领域；继承已有 projectStyleContract.toneBudget，仅补充解释，不重复旧契约正文。
