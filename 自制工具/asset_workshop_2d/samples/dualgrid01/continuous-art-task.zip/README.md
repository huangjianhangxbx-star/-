# 双网格绘画任务 ZIP9

dual-grid-spec.json为唯一权威；input原图为准确批准视觉依据，retry为待修返图。先读drawing-contract.md与prompts/agent-task.md。程序负责拓扑，不让美术人员绘制编码图。签名只证明包完整，未知发行者不授予本机批准。
