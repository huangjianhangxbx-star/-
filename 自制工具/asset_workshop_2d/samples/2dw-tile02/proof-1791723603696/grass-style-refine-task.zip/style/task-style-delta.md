# 本次偏差说明

仅作用于选定样品，不升级长期规则。

"Only an original synthetic style-step input simulation; no AI image generation."
