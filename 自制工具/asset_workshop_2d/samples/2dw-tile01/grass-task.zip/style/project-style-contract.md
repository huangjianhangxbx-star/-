# 项目风格契约

spec/asset-spec.json 是唯一权威。本文件为镜像。

{
  "schemaVersion": "2dw-project-style/1",
  "name": "星骸回廊手绘块面风格",
  "summary": "以清楚、经过设计的色块和黑色结构概括体积；控制明暗层级与细节密度。",
  "positiveRules": [
    "闭塞区域、裂缝、接触面和背光面优先用黑线、黑块或深色块概括。",
    "暗部接近黑色后停止继续刻画细节。",
    "用经过设计的装饰性块面组织体积，保留画面的整体可读性。"
  ],
  "negativeRules": [
    "避免过度精致和写实抛光感。",
    "避免 AI 式密集材质细节。",
    "避免平均铺开的裂纹和无目标噪点。"
  ],
  "toneBudget": {
    "darkMaxTiers": 3,
    "lightMaxTiers": 3
  },
  "shapeLanguageRules": [
    "形状与轮廓优先，黑色结构块承担遮挡、接触和转折。"
  ],
  "textureRules": [
    "减少碎纹理和重复噪点；让大中小块面有明确主次。"
  ],
  "renderingWarnings": [
    "仅允许少量克制的渐变，不能用平滑过渡替代块面设计。"
  ]
}
