# 制作、验证与交接计划（待外部执行）

1. 读取唯一权威 spec/asset-spec.json、manifest.json、workflow/recipe.json，以及 style/ 的项目契约和本次偏移；先核对风格边界与冲突，再核验全部实际 ZIP 条目和原始参考 PNG。
2. 按激活步骤完成带 refId 证据的内容/风格观察，写出事实、推断、已确认约束和未决项；零参考不得杜撰图像事实。
3. 综合原始用户意图和明确内容硬要求；经 decision-policy 闸门处理冲突。阻塞时停止受影响部分并如实交接。
4. 只有在必要能力和关键决策具备时，用真实可用的生图/图像编辑工具制作候选；生图能力缺失时制作阻塞，不能生成占位 PNG。
5. 对真实结果核验 PNG 字节、512×256 px、Alpha transparent-required；Unity 200 PPU 对应 2.56×1.28 世界单位。
6. 仅将合格成果写入任务目录内 output/asset.png，记录工具、来源、校验结论、未完成项和交接状态。
以上均为未来步骤；本 ZIP 不含 reports/ 下的分析、制作或交接报告，也不含 output/asset.png。
