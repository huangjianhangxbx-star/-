# 从已批准样品制作正式联通母版

先读 spec/asset-spec.json（唯一硬规格），再读 style/。若无图像能力，审阅并说明未执行，不伪称已经出图。禁止图内文字/导引/水印，不改变主体与联通要求。参考图片只有本包明确列入的角色才可使用。成熟手绘的大明暗块面，弱整体材质色差；不为填空增加纹理，不做模糊、儿童化、塑料或矢量图标。程序合格不等于人工美术验收。

input/approved-sample.png 是本任务批准的唯一视觉输入，SHA 1a385985ae80ba05fca48698ea1001ae50d759e530b7ad9b8d4cc1f0f33efbc7；审批身份见 approval.json，测试夹具批准不是用户美术认可。不能独立随意设计47块。使用 asset-grammar/grammar.json 的固定坐标/相位/尺寸/PPU/pivot，依 guides 中空板与导引画连续贴片。

返回文件：
materials.png：256×128 PNG，八个实际材质贴片，必须精确尺寸与完全不透明
contour.png：128×64 PNG，两个轮廓/暗部控制变体，必须精确尺寸与完全不透明

materials.png 上排为四个连续表面变化，下排为两个边缘变化、底层和暗面。变体中心可变，连接外缘保持相同材质相位；不画独立tile。contour.png 两个局部控制变体：R通道限定边界缩进，G通道为暗面混合权重，B必须0、A必须255；按导引范围绘制，控制图不是成品颜色。程序限制拓扑，不能改变连接通道。两张均须返回，不能用缺省图冒充画师输入。共享相位规则：edge-0 与 edge-1 外缘 depth=0 和 depth=1 的左/右 RGBA 对应相等，上/下对应相等，两个边缘变体的这些帧坐标也完全相同；不得旋转、模糊或平均边框来补缝。控制 G 必须≤192；R 的缩进映射下限 max(1,floor(cellPixels/32))、上限 max(2,floor(cellPixels/8))。patch 的精确 x/y/width/height 以 grammar.master.patches 和 grammar.control.patches 为准。seed 决定固定映射，每一合法状态生成4个变体（共188），输出 variants/mask-NNN-vV.png；canonical 47态仍保留，不能把变体覆盖成同名47文件。

修改样品或硬规格后这个包陈旧，需撤销/重新批准再导出。精确尺寸失败保留原返回图，不拉伸或事后改变契约。
