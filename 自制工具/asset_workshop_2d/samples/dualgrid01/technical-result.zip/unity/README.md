# Unity静态接入资料

Sprite Mode Multiple，4×4切割canonical16-atlas.png；Keep Empty Rects，Pivot(.5,.5)，PPU 100。像素验证用Point；Bilinear需另做atlas padding/extrusion，不修改源图来掩盖接缝。canonical只有phase0，不能还原完整连续母图的大地图；推荐自定义renderer按world坐标mod4读取phase-atlases。skner-atlas.png已按固定规则索引重排，Sprite名字必须按mapping.json的dual_N明确对应；不假设编辑器自动编号方向。只验证静态映射，没有Unity实机。Data(x,-y-1)、Render(x,-y)，单位c/PPU，Render偏移(-c/2PPU,-c/2PPU)。
